/**
 * Author: Shwetangi P
 * Description: This is a main activity in which user will enter the search text as a input in searchView.
 * - Once we get the user input, onClick of Search button we make an API call to get the response (data in JSON format).
 * - We are writing this page in Java.
 *
 */

package com.example.shapescollageactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private GridView mGridView;
    private ProgressBar mProgressBar;

    private GridViewAdapter mGridAdapter;
    //private CustomGrid mGridAdapter;
    private ArrayList<GridItem> mGridData;
    //ArrayList for Storing image urls and titles
    private String[] images;
    private String[] names;
    private ArrayList<String> imagesArrayList = new ArrayList<String>();
    private ArrayList<String> namesArrayList = new ArrayList<String>();;
    private String FEED_URL = "https://api.imgur.com/3/gallery/search/1?q=vanilla";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final SearchView searchMe = (SearchView)findViewById(R.id.search);

        mGridView = (GridView) findViewById(R.id.gridView);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        //Initialize with empty data
        mGridData = new ArrayList<>();

        mGridAdapter = new GridViewAdapter(this, R.layout.activity_details_view,mGridData);
        mGridView.setAdapter(mGridAdapter);

        //Grid view click event
        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                //Get item at position
                GridItem item = (GridItem) parent.getItemAtPosition(position);

                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                ImageView imageView = (ImageView) v.findViewById(R.id.grid_item_image);

                // Interesting data to pass across are the thumbnail size/location, the
                // resourceId of the source bitmap, the picture description, and the
                // orientation (to avoid returning back to an obsolete configuration if
                // the device rotates again in the meantime)

                int[] screenLocation = new int[2];
                imageView.getLocationOnScreen(screenLocation);

                //Pass the image title and url to DetailsActivity
                intent.putExtra("left", screenLocation[0]).
                        putExtra("top", screenLocation[1]).
                        putExtra("width", imageView.getWidth()).
                        putExtra("height", imageView.getHeight()).
                        putExtra("title", item.getTitle()).
                        putExtra("image", item.getImage());

                //Start details activity
                startActivity(intent);
            }

        });

        //Start download
       //sererCall();
        new MainActivity.AsyncHttpTask().execute(FEED_URL);
        mProgressBar.setVisibility(View.VISIBLE);


    }

    //Downloading data asynchronously
    public class AsyncHttpTask extends AsyncTask<String, Void, Integer> {
        Integer result = 0;
        Request request;
        @Override
        protected Integer doInBackground(String... strings) {
           // String searchText = "vanilla";
            try {
            OkHttpClient client = new OkHttpClient();
            request = new Request.Builder()
                    .url("https://api.imgur.com/3/gallery/search/1?q=vanilla")
                    .get()
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Authorization", "Client-ID 137cda6b5008a7c")
                    .addHeader("cache-control", "no-cache")
                    .build();
                Response httpResponse = client.newCall(request).execute();
                int statusCode = httpResponse.code();
                if (statusCode == 200) {
                    String html = httpResponse.body().string();
                    result=1;
                    parseResult(html);

                    Log.d("showing html 00000   ",html);
                }else{
                    result=0;
                }

            } catch (IOException e) {
                Log.d("Request call string :- ", request.toString());
                e.printStackTrace();
            }
            return result;
        }
        @Override
        protected void onPostExecute(Integer result) {
            // Download complete. Lets update UI

            if (result == 1) {

                mGridAdapter.setGridData(mGridData);
                mGridView.setAdapter(mGridAdapter);
            } else {
                Toast.makeText(MainActivity.this, "Failed to fetch data!", Toast.LENGTH_SHORT).show();
            }

            //Hide progressbar
            mProgressBar.setVisibility(View.GONE);
        }
    }
    /**
     * Parsing the feed results and get the list
     *
     * @param result
     */
    private void parseResult(String result) {
        try {
            JSONObject response = new JSONObject(result);
            JSONArray data = response.getJSONArray("data");
            GridItem item = new GridItem();
            String image = "";
            String titles = "";
            for (int i = 0; i < data.length(); i++) {
                JSONObject obj = data.getJSONObject(i);
                titles = obj.getString("title");

                item = new GridItem();
                item.setTitle(titles);
                image = obj.getString("link");
                item.setImage(image);

                imagesArrayList.add(image);
                namesArrayList.add(titles);
                mGridData.add(item);
                }

//            images = imagesArrayList.toArray(new String[0]);
//            names = namesArrayList.toArray(new String[0]);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
