package com.example.shapescollageactivity;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class GridViewAdapter extends ArrayAdapter<GridItem> {

    //private final ColorMatrixColorFilter grayscaleFilter;
    private Context mContext;

    private int layoutResourceId;
    private ArrayList<GridItem> mGridData;

    public GridViewAdapter(Context mContext, int layoutResourceId, ArrayList<GridItem> mGridData) {
        super(mContext, layoutResourceId, mGridData);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.mGridData = mGridData;
    }

    /**
     * Updates grid data and refresh grid items.
     *
     * @param mGridData
     */
    public void setGridData(ArrayList<GridItem> mGridData) {
        this.mGridData = mGridData;
        notifyDataSetChanged();
    }
    public int getCount(){
       return mGridData.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View grid = null;
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
            grid = inflater.inflate(layoutResourceId, parent,false);

            TextView titleTextView = (TextView) grid.findViewById(R.id.grid_item_title);
            ImageView imageView = (ImageView) grid.findViewById(R.id.grid_item_image);

            GridItem item = mGridData.get(position);
            titleTextView.setText(Html.fromHtml(item.getTitle()));
            Picasso.with(mContext).load(item.getImage()).into(imageView);
        } else {

            grid = (View) convertView;
        }

        return grid;
    }

    static class ViewHolder {
        TextView titleTextView;
        ImageView imageView;
    }
}