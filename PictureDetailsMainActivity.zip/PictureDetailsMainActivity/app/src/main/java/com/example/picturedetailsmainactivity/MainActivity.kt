package com.example.picturedetailsmainactivity

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.mylayout.view.*


class MainActivity : AppCompatActivity() {
    var adapter : ImageAdapter? = null
var imageList = ArrayList<ImageGridView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageList.add(ImageGridView("first","desc o",R.drawable.eighth))
        imageList.add(ImageGridView("first","desc o",R.drawable.fifth))
        imageList.add(ImageGridView("first","desc o",R.drawable.fourth))
        imageList.add(ImageGridView("first","desc o",R.drawable.nature))
        imageList.add(ImageGridView("first","desc o",R.drawable.second))
        imageList.add(ImageGridView("first","desc o",R.drawable.third))
        imageList.add(ImageGridView("first","desc o",R.drawable.sixth))

        adapter = ImageAdapter(this,imageList)
        gridviewd.adapter = adapter
    }


    class ImageAdapter : BaseAdapter{
        var imageList = ArrayList<ImageGridView>()
        var context: Context ? = null

        constructor(context: Context?, imageList: ArrayList<ImageGridView> ) : super() {
            this.imageList = imageList
            this.context = context
        }


        override fun getView(Index: Int, p1: View?, p2: ViewGroup?): View {
           var image: ImageGridView = this.imageList[Index]
            var inflater = context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            var imagesview = inflater.inflate(R.layout.mylayout,null)

            imagesview.imageView.setImageResource(image.image!!)

            imagesview.imageView.setOnClickListener{
                var intent = Intent(context, ImageDetailActivity::class.java)
                intent!!.putExtra("image",image.image!!)
                context!!.startActivity(intent)
            }

            return imagesview
        }

        override fun getItem(p0: Int): Any {
            return p0
        }

        override fun getItemId(p0: Int): Long {
           return p0.toLong()
        }

        override fun getCount(): Int {
            return imageList.size
        }


    }
}