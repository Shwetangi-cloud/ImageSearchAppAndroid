package com.example.picturedetailsmainactivity

class ImageGridView {
    var name: String? = null
    var image: Int? = null
    var desc:String? = null

    constructor(name: String?, desc: String?,image: Int?) {
        this.name = name
        this.desc = desc
        this.image = image
    }
}